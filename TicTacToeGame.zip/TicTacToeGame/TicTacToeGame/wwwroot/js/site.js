﻿let currentPlayer = 'X';
let board = Array(9).fill(null);
let gameActive = true;
let isAIMode = false;

// Track scores
let playerXScore = 0;
let playerOScore = 0;
let drawScore = 0;

const cells = document.querySelectorAll('.cell');
const statusDisplay = document.getElementById('game-status');
const restartButton = document.getElementById('restart-btn');
const modeButton = document.getElementById('mode-btn');
const playerXScoreDisplay = document.getElementById('playerX-score');
const playerOScoreDisplay = document.getElementById('playerO-score');
const drawScoreDisplay = document.getElementById('draw-score');

const winningConditions = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6]             // Diagonals
];

// Handle cell clicks
function handleCellClick(event) {
    if (isAIMode && currentPlayer === 'O') return;

    const cell = event.target;
    const index = parseInt(cell.getAttribute('data-row')) * 3 + parseInt(cell.getAttribute('data-col'));

    if (board[index] || !gameActive) return;

    board[index] = currentPlayer;
    cell.textContent = currentPlayer;

    if (checkWin(currentPlayer)) {
        statusDisplay.textContent = `Player ${currentPlayer} wins!`;
        updateScoreboard(currentPlayer);
        gameActive = false;
        return;
    }

    if (board.every(cell => cell !== null)) {
        statusDisplay.textContent = "It's a draw!";
        updateScoreboard('draw');
        gameActive = false;
        return;
    }

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';

    if (isAIMode && currentPlayer === 'O') {
        setTimeout(makeAIMove, 500);
    }
}

// Check for a win
function checkWin(player) {
    return winningConditions.some(condition => {
        return condition.every(index => {
            return board[index] === player;
        });
    });
}

// Update the scoreboard
function updateScoreboard(winner) {
    if (winner === 'X') {
        playerXScore++;
    } else if (winner === 'O') {
        playerOScore++;
    } else {
        drawScore++;
    }

    playerXScoreDisplay.textContent = playerXScore;
    playerOScoreDisplay.textContent = playerOScore;
    drawScoreDisplay.textContent = drawScore;
}

// Restart the game
function restartGame() {
    board.fill(null);
    cells.forEach(cell => cell.textContent = '');
    statusDisplay.textContent = '';
    currentPlayer = 'X';
    gameActive = true;
}

// Minimax algorithm for AI
function minimax(board, depth, isMaximizing) {
    if (checkWin('X')) return -10 + depth;
    if (checkWin('O')) return 10 - depth;
    if (board.every(cell => cell !== null)) return 0;

    if (isMaximizing) {
        let bestScore = -Infinity;
        for (let i = 0; i < 9; i++) {
            if (board[i] === null) {
                board[i] = 'O';
                let score = minimax(board, depth + 1, false);
                board[i] = null;
                bestScore = Math.max(score, bestScore);
            }
        }
        return bestScore;
    } else {
        let bestScore = Infinity;
        for (let i = 0; i < 9; i++) {
            if (board[i] === null) {
                board[i] = 'X';
                let score = minimax(board, depth + 1, true);
                board[i] = null;
                bestScore = Math.min(score, bestScore);
            }
        }
        return bestScore;
    }
}

// Make AI move
function makeAIMove() {
    let bestScore = -Infinity;
    let move;
    for (let i = 0; i < 9; i++) {
        if (board[i] === null) {
            board[i] = 'O';
            let score = minimax(board, 0, false);
            board[i] = null;
            if (score > bestScore) {
                bestScore = score;
                move = i;
            }
        }
    }
    board[move] = 'O';
    cells[move].textContent = 'O';

    if (checkWin('O')) {
        statusDisplay.textContent = 'AI wins!';
        updateScoreboard('O');
        gameActive = false;
    } else if (board.every(cell => cell !== null)) {
        statusDisplay.textContent = "It's a draw!";
        updateScoreboard('draw');
        gameActive = false;
    }
    currentPlayer = 'X';
}

// Switch between AI and Player modes
modeButton.addEventListener('click', () => {
    isAIMode = !isAIMode;
    restartGame();
    modeButton.textContent = isAIMode ? 'Switch to Player Mode' : 'Switch to AI Mode';
});

// Add event listeners
cells.forEach(cell => cell.addEventListener('click', handleCellClick));
restartButton.addEventListener('click', restartGame);