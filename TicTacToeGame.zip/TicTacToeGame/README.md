PARREÑO, AXEL GREG T.	BSIT 3-E 20941

TIC-TAC-TOE (Razor Pages)

After unzipping the zip file, access the files in Visual Studio 2022
then run the Index.cshtml(ctrl + F5 for shortcut).

In the webpage, the default game is a multiplayer tictactoe game
which is Player vs Player; there is an option to switch to a singleplayer mode(Player vs AI)
right beside the restart button. The restart button's function is to re-start an on going game, therefore no scores is recorded in the scoreboard when you restart a game.